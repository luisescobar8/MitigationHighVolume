from config import *
from manager import TopoManager, IntentManager
import logging
import time
import optparse
import sys
import threading
sys.path.insert(0, '/home/marcelo/Documents/ReactiveSecuritySolution/ids')
temp = {}
ids_slow_rate_Flows = {}
ids_high_rate_Flows = {}
from IDS_Server import *
#from IDS_highrate_Server import *
intentManager = IntentManager()
def dropMitigation():
        for flowid, info in (ids_slow_rate_Flows.copy()).items():
            if(info["pred_label"]) == 'normal':
                del ids_slow_rate_Flows[flowid]
        if len(ids_slow_rate_Flows):
            logging.info("[IPS]: %s",ids_slow_rate_Flows)
            # send list of malicious ips
            intentManager.dropCommand(ids_slow_rate_Flows)
        

def ips_function(name):
    global temp, ids_slow_rate_Flows
    while(True):
        # slow rate
        temp = getids_slowrate_Flows()
        if len(temp)>0: 
            ids_slow_rate_Flows = temp.copy()
            logging.info("[IDS]: %s",ids_slow_rate_Flows)
            dropMitigation()

        # high rate
        temp = getids_highrate_Flows()
        if len(temp)>0: 
            ids_high_rate_Flows = temp.copy()
            logging.info("[IDS]: %s",ids_high_rate_Flows)

        time.sleep(1)


def start_IDS_Server():
    load_lstm_model() # slow rate
    load_lstm_model_2() # high rate
    app.run(debug=True, host='0.0.0.0', port = 9001)

if __name__ == '__main__':
    # start IDS
    x = threading.Thread(target=ips_function, args=(1,))
    x.start()

    start_IDS_Server()


    #parser = optparse.OptionParser()
    #parser.add_option("--one-shot", action="store_true", dest="oneshot", default=False, help="poll only once")
    #(options, args) = parser.parse_args()

    #topoManager = TopoManager()
    #if topoManager.is_topo_available():
        #topoManager.draw_topo()
    #    intentManager = IntentManager()
    #    for i in range(0,20):
    #        intentManager.rerouteMY(topoManager.graph)


    #if not options.oneshot:
    #    while True:
    #        topoManager = TopoManager()
    #        if not topoManager.is_topo_available():
    #            time.sleep(1)
    #            continue
    #        #topoManager.draw_topo()
    #        if topoManager.is_congestion:
    #            logging.info("Detect traffic congestion...")
    #            intentManager = IntentManager()
    #            intentManager.reroute(topoManager.graph)
    #        else:
    #            logging.info("Traffic is light...")
    #            time.sleep(POLLING_INTERVAL)
    #else:
    #    topoManager = TopoManager()
    #    if topoManager.is_topo_available():
    #        intentManager = IntentManager()
    #        intentManager.reroute(topoManager.graph)


