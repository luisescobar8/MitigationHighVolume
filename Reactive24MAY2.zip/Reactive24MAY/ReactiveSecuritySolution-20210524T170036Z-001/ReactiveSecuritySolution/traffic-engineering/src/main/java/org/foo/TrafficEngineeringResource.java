package org.foo;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import org.onosproject.net.flow.DefaultTrafficSelector;
import org.onosproject.net.flow.DefaultTrafficTreatment;
import org.onosproject.net.flow.TrafficSelector;
import org.onosproject.net.flow.TrafficTreatment;
import org.onosproject.net.flowobjective.DefaultForwardingObjective;
import org.onosproject.net.flowobjective.ForwardingObjective;
import org.onosproject.net.flowobjective.FlowObjectiveService;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.onlab.packet.IpAddress;

import javax.ws.rs.*;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.onlab.graph.ScalarWeight;
import org.onosproject.core.ApplicationId;
import org.onosproject.core.CoreService;
import org.onosproject.net.statistic.PortStatisticsService;
import org.onosproject.net.flow.*;
import org.onosproject.net.host.HostService;
import org.onosproject.net.intent.*;
import org.onosproject.net.intent.util.IntentFilter;
import org.onosproject.net.provider.ProviderId;
import org.onosproject.net.topology.PathService;
import org.onosproject.rest.AbstractWebResource;
import org.onosproject.net.link.*;
import org.onosproject.net.*;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;  
import java.util.Set;  



/**
 * REST API for bandwidth monitoring and path rerouting among network.
 */
@Path("")
public class TrafficEngineeringResource extends AbstractWebResource {

    private final Logger log = LoggerFactory.getLogger(getClass());
    private static final int DROP_RULE_TIMEOUT = 50;
    
    @GET
    @Path("/test")
    public Response getTest() {
        ObjectNode responseBody = new ObjectNode(JsonNodeFactory.instance);
        responseBody.put("message", "it works!");
        return Response.status(200).entity(responseBody).build();
    }

    /**
     * Get bandwidth from all links and edges.
     *
     * @return 200 OK
     */
    @GET
    @Path("bandwidth/topology")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTopologyBandwidth() {

        LinkService linkService = get(LinkService.class);
        HostService hostService = get(HostService.class);
        PortStatisticsService portStatisticsService = get(PortStatisticsService.class);
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode rootNode_ = mapper.createObjectNode();

        ArrayNode linksNode = mapper.createArrayNode();
        for (Link link: linkService.getActiveLinks()){

            long srcBw = portStatisticsService.load(link.src()).rate() * 8 / 1000;
            long dstBw = portStatisticsService.load(link.dst()).rate() * 8 / 1000;

            // unit: Kbps
            if (link.src().deviceId().toString().equals("of:0000000000000065") || link.dst().deviceId().toString().equals("of:0000000000000065")) continue; // ignore traffic mirroring SW
            ObjectNode linkNode = mapper.createObjectNode()
                    .put("src", link.src().deviceId().toString())
                    .put("dst", link.dst().deviceId().toString())
                    .put("bw", (srcBw + dstBw) / 2 );

            linksNode.add(linkNode);
        }

        rootNode_.set("links", linksNode);

        ArrayNode edgesNode = mapper.createArrayNode();
        for (Host host: hostService.getHosts()){
            // unit: Kbps
            if(host.location().deviceId().toString().equals("of:0000000000000065")) continue; // ignore flow collector PC
            ObjectNode hostNode = mapper.createObjectNode()
                    .put("host", host.id().toString())
                    .put("location", host.location().deviceId().toString())
                    .put("bw", portStatisticsService.load(host.location()).rate() * 8 / 1000);

            edgesNode.add(hostNode);
        }

        rootNode_.set("edges", edgesNode);

        return ok(rootNode_).build();

    }

    /**
     * Get state of connectivity between two hosts. 
     *
     * @return 200 OK
     */
    @GET
    @Path("state/connectivity")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getConnectivityBandwidth() {

        CoreService coreService = get(CoreService.class);
        IntentService intentService = get(IntentService.class);
        FlowRuleService flowRuleService = get(FlowRuleService.class);
        IntentFilter intentFilter = new IntentFilter(intentService, flowRuleService);
        HostService hostService = get(HostService.class);
        LinkService linkService = get(LinkService.class);

        ObjectMapper mapper = new ObjectMapper();
        ObjectNode rootNode = mapper.createObjectNode();
        ArrayNode connsNode = mapper.createArrayNode();

        ApplicationId h2hAppId = coreService.getAppId("mx.itesm.intentBasedNetworking");
        ApplicationId pathAppId = coreService.getAppId("org.foo.path");

        for (Intent intent : intentService.getIntents()) {
            // require host-to-host intent or path intent
            ApplicationId appId = intent.appId();
            if(appId.equals(h2hAppId) || appId.equals(pathAppId)) {
                List<Intent> installable = intentService.getInstallableIntents(intent.key());
                // intent-related flow entries
                List<List<FlowEntry>> flowEntriesList = intentFilter.readIntentFlows(installable);
                if(flowEntriesList.size() == 0) continue;
                List<FlowEntry> flowEntries = flowEntriesList.get(0);
                long _life = 0;
                long _byte = 0;
                long _flowId = 0;
                // select flow entry with max life for this intent
                for(FlowEntry flowEntry: flowEntries) {
                    if (flowEntry.life() > _life) {
                        _life = flowEntry.life();
                        _byte = flowEntry.bytes();
                        _flowId = flowEntry.id().value();
                    }
                }
                Iterator<NetworkResource> resourcesIterator = intent.resources().iterator();
                DeviceId srcDev = null;
                DeviceId dstDev = null;
                HostId oneId  = null;
                HostId twoId  = null;

                if (intent instanceof PointToPointIntent) {
                    ConnectPoint connectPointOut = ((PointToPointIntent) intent).filteredEgressPoint().connectPoint();
                    Link linkconn = getNodesConnection(linkService, connectPointOut);
                    if (linkconn==null) continue;
                    srcDev = linkconn.src().deviceId();
                    dstDev = linkconn.dst().deviceId();
                }
                if (intent instanceof SinglePointToMultiPointIntent) {
                    ConnectPoint connectPointOut = ((((SinglePointToMultiPointIntent) intent).filteredEgressPoints()).iterator()).next().connectPoint();
                    Link linkconn = getNodesConnection(linkService, connectPointOut);
                    if (linkconn==null) continue;
                    srcDev = linkconn.src().deviceId();
                    dstDev = linkconn.dst().deviceId();
                }
                if (intent instanceof PathIntent) {
                    while(resourcesIterator.hasNext()){
                        NetworkResource networkResource = resourcesIterator.next();
                        if (networkResource instanceof DefaultEdgeLink) {
                            if (oneId == null) {
                                oneId = ((DefaultEdgeLink) networkResource).hostId();
                            }
                            else if (twoId == null){
                                twoId = ((DefaultEdgeLink) networkResource).hostId();
                            }
                        }
                    }
                }
                ObjectNode node = mapper.createObjectNode();
                node.put( "one", srcDev.toString())
                        .put("two", dstDev.toString())
                        .put("byte", _byte)
                        .put("life", _life)
                        .put("flowid", _flowId)
                        .put("appid", intent.appId().name());
                connsNode.addPOJO(node);
            }
        }

        rootNode.set("connectivities", connsNode);

        return ok(rootNode).build();

    }

    /**
     * Post a list of rerouting paths.
     *
     * @param stream input JSON
     * @return 200 OK
     */
    @POST
    @Path("reroute")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response reRouteIntents(InputStream stream) {

        ObjectMapper mapper = new ObjectMapper();

        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);

        try {

            ObjectNode rootNode = mapper.createObjectNode();

            ProviderId providerId = new ProviderId("provider.scheme", "provider.id");
            Routes routes = mapper.readValue(stream, Routes.class);



            List<Route> routeList = routes.getPaths();
            if (routeList == null || routeList.size() == 0) {
                rootNode.put("response", "no paths");
                return ok(rootNode).build();
            }
            for (Route route : routeList) {
                HostId srcId = route.getSrcId();
                HostId dstId = route.getDstId();
                List<DeviceId> deviceIds = route.getDeviceIds();
                submitPathIntent(providerId, deviceIds, srcId, dstId);
            }

            rootNode.put("response", "OK");
            return ok(rootNode).build();

        } catch (Exception e) {
            return Response
                    .status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity(e.toString())
                    .build();
        }

    }

    private void submitPathIntent(ProviderId providerId, List<DeviceId> deviceIds, HostId srcId, HostId dstId) {
        
        HostService hostService = get(HostService.class);
        PathService pathService = get(PathService.class);
        IntentService intentService = get(IntentService.class);
        CoreService coreService = get(CoreService.class);

        List<Link> links = new ArrayList<>();

        EdgeLink srcLink = new DefaultEdgeLink(providerId, new ConnectPoint((ElementId) srcId, PortNumber.portNumber(0)), hostService.getHost(srcId).location(),true);
        links.add(srcLink);

        int deviceNum = deviceIds.size();
        for (int i = 0; i < deviceNum - 1; i++) {
            links.addAll(pathService
                    .getPaths(deviceIds.get(i), deviceIds.get(i + 1))
                    .iterator()
                    .next()
                    .links()
            );
        }

        EdgeLink dstLink = new DefaultEdgeLink(providerId, new ConnectPoint((ElementId) dstId, PortNumber.portNumber(0)), hostService.getHost(dstId).location(),false);
        links.add(dstLink);

        int priority = 1;

        // set priority of this path intent the same as the existing one
        ApplicationId appId = coreService.registerApplication("org.foo.path");
        Key key = Key.of("Path(" + srcId.toString() + dstId.toString() + ")", appId);
        PathIntent pathIntent = (PathIntent) intentService.getIntent(key);
        if(pathIntent != null) {
            priority = pathIntent.priority();
            // remove the existing one
            while (intentService.getIntent(key) != null) {
                intentService.withdraw(pathIntent);
                intentService.purge(pathIntent);
            }
        }

        // set priority of this path intent higher than host to host intent which builds shortest path
        ApplicationId h2hAppId = coreService.getAppId("mx.itesm.intentBasedNetworking");
        Key h2hIntentKey;
        if(srcId.toString().compareTo(dstId.toString()) < 0) {
            h2hIntentKey= Key.of(srcId.toString() + dstId.toString(), h2hAppId);
        } else {
            h2hIntentKey = Key.of( dstId.toString() + srcId.toString(), h2hAppId);
        }
        HostToHostIntent h2hIntent = (HostToHostIntent) intentService.getIntent(h2hIntentKey);
        if(h2hIntent != null && intentService.getIntentState(h2hIntentKey) == IntentState.INSTALLED) {
            priority = h2hIntent.priority();
        }

        pathIntent = PathIntent.builder()
                .path( new DefaultPath(providerId, links, ScalarWeight.toWeight(1)))
                .appId(appId)
                .key(key)
                .priority(priority + 1)
                .selector(DefaultTrafficSelector.builder().matchEthSrc(srcId.mac()).matchEthDst(dstId.mac()).build())
                .treatment(DefaultTrafficTreatment.emptyTreatment())
                .build();

        // submit path intent
        while (intentService.getIntent(key) == null) {
            intentService.submit(pathIntent);
        }

    }

    private Link getNodesConnection(LinkService linkService, ConnectPoint connectPoint) {

        for (Link link: linkService.getActiveLinks()){
           // unit: Kbps
            if (link.src().deviceId().toString().equals("of:0000000000000065") || link.dst().deviceId().toString().equals("of:0000000000000065")) continue; // ignore traffic mirroring SW
            if (connectPoint.equals(link.src())) {
                    return link;
            }         
        }

        return null;

    }

    /**
     * Post a list of dropping pairs of hosts.
     *
     * @param stream input JSON
     * @return 200 OK
     */
    @POST
    @Path("dropping")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response droppingStrategy(InputStream stream) {
        HostService hostService = get(HostService.class);
        FlowObjectiveService flowObjectiveService = get(FlowObjectiveService.class);
        CoreService coreService = get(CoreService.class);
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);
        ApplicationId appId = coreService.registerApplication("org.foo.path");

        try {

            ObjectNode rootNode = mapper.createObjectNode();

            ProviderId providerId = new ProviderId("provider.scheme", "provider.id");
            Map<String, Object> suspicious_ = mapper.readValue(stream, Map.class);
            //Routes routes = mapper.readValue(stream, Routes.class);

            if (suspicious_ == null || suspicious_.size() == 0) {
                rootNode.put("response", "No given hosts to drop packets");
                return ok(rootNode).build();
            }

             for (Map.Entry<String, Object> entry : suspicious_.entrySet()) {
                String src = (((Map)entry.getValue()).get("src")).toString();
                String dst = (((Map)entry.getValue()).get("dst")).toString();
                int    protocol = (int) ((Map)entry.getValue()).get("protocol");
                HostId srcId = null;
                HostId dstId = null;
                log.info("Inserting drop rules for: src: {}, dst: {}, protocol : {}", src, dst, protocol);
                Set<Host> hosts = hostService.getHostsByIp(IpAddress.valueOf(src));
                if (hosts.isEmpty()) continue;
                for (Host host: hosts) {
                    srcId = host.id();
                }
                hosts = hostService.getHostsByIp(IpAddress.valueOf(dst));
                if (hosts.isEmpty()) continue;
                for (Host host: hosts) {
                    dstId = host.id();
                }

                if (srcId == null || dstId == null) continue;
                TrafficSelector objectiveSelector = DefaultTrafficSelector.builder()
                        .matchEthSrc(srcId.mac()).matchEthDst(dstId.mac()).build();

                TrafficTreatment dropTreatment = DefaultTrafficTreatment.builder()
                        .drop().build();

                ForwardingObjective objective = DefaultForwardingObjective.builder()
                        .withSelector(objectiveSelector)
                        .withTreatment(dropTreatment)
                        .fromApp(appId)
                        .withPriority(101)
                        .makeTemporary(DROP_RULE_TIMEOUT)
                        .withFlag(ForwardingObjective.Flag.VERSATILE)
                        .add();

                // at src device
                flowObjectiveService.forward(hostService.getHost(srcId).location().deviceId(),
                                         objective);
                // at dst device
                /*if (hostService.getHost(dstId).location().equals(hostService.getHost(dst).location())) {
                    flowObjectiveService.forward(hostService.getHost(dst).location(),
                                         objective);
                }*/
                
                } 

            rootNode.put("response", "OK");
            return ok(rootNode).build();

        } catch (Exception e) {
            return Response
                    .status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity(e.toString())
                    .build();
        }

    }

}
