# -*- coding: utf-8 -*-
"""
Created on Mon Sep  7 10:40:31 2020

@author: Marcelo
"""
from flask import Flask, request, abort
from keras.models import load_model
from numpy import load
import pickle, time
import os
import logging
import pandas as pd
logging.basicConfig(level=logging.DEBUG)
import sys
import numpy as np
app = Flask(__name__)
ids_slowrate_Flows = {}
ids_highrate_Flows = {}

# slow rate
columns = [ # flow identifier
		'SWID',
		'Protocol',
		'SrcIP', 
		'SrcPort',
		'DstIP',
		'DstPort',
		"Timestamp"]
class_values = {
    0:"normal",
    1:"slowbody2",
    2:"slowread",
    3:"ddossim",
    4:"goldeneye",
    5:"slowheaders",
    6:"rudy",
    7:"hulk",
    8:"slowloris",
    9:"incomplete"
}
# Modify according to your targets
nsteps = 3   # for memoryless models, n = 1

ip_attacker   = "10.0.0.7"
ip_victim     = "10.0.0.1" 
currentAttack = "incomplete"   # copy from class_values*, needs to be precise
experiment = "_rate_300_conn_8000"
lstmModel = None
yytest = []
center = None
scale  = None
pca    = None
xtest = []
totalFlows=0 # total of flows received
file1 = "/home/marcelo/Documents/ExperimentsMitigation/eval-"+currentAttack+experiment+".txt"
modelPath  = "/home/marcelo/Documents/ReactiveSecuritySolution/ids/slow-rate/lstm/"

	
def raw_flow_to_values(flow):
	return [list(flow.values())]

def load_lstm_model():
    global lstmModel, yytest, center, scale, pca
    lstmModel = load_model(modelPath+'LSTM')
    center = load(modelPath+'center.npy')
    scale = load(modelPath+'scale.npy')
    pca = load(modelPath+'pca.npy')
def preprocessing(x_received):
     xn = (x_received-center)/scale
     xpca = (np.resize(xn,(1,len(xn)))).dot(pca)
     return xpca
def addapting(x):
    if len(xtest) < nsteps-1:
        xtest.append(x)
        return False
    else:
        xtest.append(x)
        return True
def getids_slowrate_Flows():
	global ids_slowrate_Flows
	r = ids_slowrate_Flows.copy()
	ids_slowrate_Flows.clear()
	return r
def getids_highrate_Flows():
	global ids_highrate_Flows
	r = ids_highrate_Flows.copy()
	ids_highrate_Flows.clear()
	return r

def evaluating(ipsource, ipdestination, sourcePort, dstPort, protocol,timeStamp, pred_label):
    global totalFlows, ip_attacker,ip_victim,currentAttack,file1, ids_slowrate_Flows
    totalFlows = totalFlows + 1
    if pred_label != "incomplete": # systems with memory
        real_label = "normal"
        if ipsource == ip_attacker or ipsource == ip_victim: # labeled as an attack
            real_label =  currentAttack
        print("Real: ",real_label,"Predicted: ",pred_label)
        with open(file1,"a") as f:
            f.write(str(ipsource)+','+str(ipdestination)+ ','+str(sourcePort)+ ','+str(dstPort)+ ','+str(protocol)+ ','+str(timeStamp)+','+str(real_label)+','+str(pred_label)+','+str(totalFlows)+'\n')
        ids_slowrate_Flows[str(ipsource)+','+str(ipdestination)+ ','+str(sourcePort)+ ','+str(dstPort)+ ','+str(protocol)] = {'src':str(ipsource), 'dst':str(ipdestination), 'protocol':protocol, 'pred_label':str(pred_label),'totalFlows':totalFlows}
    return 0
 
@app.route("/predict/slowrate", methods=['GET','POST'])
def test():
	global xtest, lstmModel  
	yyhat = 9                       # incomplete state, if nstep>1, LSTM and GRU
	if request.method == 'POST':
		values = request.json
		df = pd.DataFrame.from_dict(values, orient='index')
		df = df[0]
		ipsource = df['SrcIP']
		sourcePort = df['SrcPort']
		ipdestination = df['DstIP']
		dstPort = df['DstPort']
		protocol = df['Protocol']
		timeStamp = df['Timestamp']     
		df.drop(columns,axis='rows',inplace=True)
		df = df.values.tolist()
		x_pca = preprocessing(np.array(df))
		if addapting(x_pca):
		    xxtest = np.array(xtest)
		    xtest = []
		    xxtest = (np.resize(xxtest,(len(xxtest),15)))
		    xxtest = np.array([xxtest])
		    yyhat = lstmModel.predict(xxtest)
		    yyhat = np.argmax(yyhat)
		    print(class_values[yyhat])
	evaluating(ipsource, ipdestination, sourcePort, dstPort, protocol,timeStamp ,class_values[yyhat])
	return class_values[yyhat],202

	


# High rate
xtest_2 = []
lstmModel_2 = None
totalFlows_2 = 0 # total of flows received

columns_2 = [ # clean data according to pre-processing
		'SWID',
		'Protocol',
		'SrcIP', 
		'SrcPort',
		'DstIP',
		'DstPort',
		"Timestamp"
        ]
class_values_2 = {
    0:"normal",
    1:"syn",
    2:"udp",
    3:"dns",
    4:"incomplete"
}
# Modify according to your targets
nsteps_2 = 5   # for memoryless models, n = 1
ip_attacker_2_1   = "10.0.0.7"
ip_attacker_2_2   = "10.0.0.8"
ip_attacker_2_3   = "10.0.0.9"
ip_victim_2_1     = "10.0.0.1" 
ip_victim_2_2     = "10.0.0.2" 
ip_victim_2_3     = "10.0.0.3" 
currentAttack_2 = "syn"   # copy from class_values*, needs to be precise
experiment_2 = "_rate_flood_conn_3000"
file_2_1 = "/home/marcelo/Documents/ExperimentsMitigation/eval-"+currentAttack_2 +experiment_2 +".txt"
modelPath_2  = "/home/marcelo/Documents/ReactiveSecuritySolution/ids/high-volume/lstm/"
center_2 = None
scale_2  = None
pca_2    = None

def raw_flow_to_values_2(flow):
	return [list(flow.values())]

def load_lstm_model_2():
    global lstmModel_2, yytest_2, center_2, scale_2, pca_2
    lstmModel_2 = load_model(modelPath_2+'lstm')
    center_2 = load(modelPath_2+'center.npy')
    scale_2 = load(modelPath_2+'scale.npy')
    pca_2 = load(modelPath_2+'pca.npy')
def preprocessing_2(x_received):
     xn = (x_received-center_2)/scale_2
     xpca = (np.resize(xn,(1,len(xn)))).dot(pca_2)
     return xpca
def addapting_2(x):
    global xtest_2, nsteps_2
    if len(xtest_2) < nsteps_2-1:
        xtest_2.append(x)
        return False
    else:
        xtest_2.append(x)
        return True
def evaluating_2(ipsource, ipdestination, sourcePort, dstPort, protocol,timeStamp, pred_label):
    global totalFlows_2, ip_attacker_2,ip_victim_2,currentAttack_2,file_2_1, ids_highrate_Flows
    totalFlows_2 = totalFlows_2 + 1
    if pred_label != "incomplete": # systems with memory
        real_label = "normal"
        if (ipsource == ip_attacker_2_1 or ipsource == ip_victim_2_1 or ipsource == ip_attacker_2_2 or ipsource == ip_victim_2_2 or ipsource == ip_attacker_2_3 or ipsource == ip_victim_2_3): # labeled as an attack
            real_label =  currentAttack_2
        print("Real: ",real_label,"Predicted: ",pred_label)
        with open(file_2_1,"a") as f:
            f.write(str(ipsource)+','+str(ipdestination)+ ','+str(sourcePort)+ ','+str(dstPort)+ ','+str(protocol)+ ','+str(timeStamp)+','+str(real_label)+','+str(pred_label)+','+str(totalFlows_2)+'\n')
        ids_highrate_Flows[str(ipsource)+','+str(ipdestination)+ ','+str(sourcePort)+ ','+str(dstPort)+ ','+str(protocol)] = {'server': 'high-rate','timeStamp': str(timeStamp), 'pred_label': str(pred_label),'totalFlows':totalFlows_2}
    return 0

@app.route("/predict/highrate", methods=['GET','POST'])
def test2():
	global xtest_2, lstmModel_2  
	yyhat = 4                      # incomplete state, if nstep>1, LSTM and GRU
	if request.method == 'POST':
		values = request.json
		df = pd.DataFrame.from_dict(values, orient='index')
		df = df[0]
		ipsource = df['SrcIP']
		sourcePort = df['SrcPort']
		ipdestination = df['DstIP']
		dstPort = df['DstPort']
		protocol = df['Protocol']
		timeStamp = df['Timestamp']     
		df.drop(columns_2,axis='rows',inplace=True)
		df = df.values.tolist()
		x_pca = preprocessing_2(np.array(df))
		if addapting_2(x_pca):
		    xxtest = np.array(xtest_2)
		    xtest_2 = []
		    xxtest = (np.resize(xxtest,(len(xxtest),15)))
		    xxtest = np.array([xxtest])
		    yyhat = lstmModel_2.predict(xxtest)
		    yyhat = np.argmax(yyhat)
		    print(class_values_2[yyhat])
	evaluating_2(ipsource, ipdestination, sourcePort, dstPort, protocol,timeStamp ,class_values_2[yyhat])
	return class_values_2[yyhat],202
 

 
 
